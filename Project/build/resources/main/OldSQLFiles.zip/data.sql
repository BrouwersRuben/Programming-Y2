INSERT INTO TYPES_OF_BUILDINGS(CODE, TYPE, REQUIRES_SPECIAL_PERMISSION) VALUES
    ('st8j', 'residential', TRUE),
    ('a2nb', 'educational', FALSE),
    ('hjw6', 'commercial', FALSE),
    ('h5bp', 'institutional', FALSE),
    ('s3n', 'business', FALSE),
    ('5huy', 'industrial', TRUE),
    ('gy1w', 'storage', FALSE),
    ('n0jx', 'detached', FALSE),
    ('q9qj', 'highrise', TRUE),
    ('gp7j', 'slums', TRUE),
    ('r3cZ', 'unsafe', FALSE),
    ('k6ca', 'special', FALSE),
    ('Z1og', 'parking', TRUE);

INSERT INTO BUILDINGS(ID, NAME, LOCATION, HEIGHT, TYPE)VALUES
    (0, 'Port Authority', 'Antwerp, Belgium', 46, 'business'),
    (1, 'Vitra Fire Station', 'Weil-am-Reinn, Germany', 12, 'institutional'),
    (2, 'Sydney Opera House', 'Sydney, Australia', 65, 'special'),
    (3, 'The Uno-X Petrol Station', 'Denmark', 10,'commercial');

--YYYY-MM-DD
INSERT INTO ARCHITECTS(ID, NAME, ESTABLISHMENT_DATE, NUMBER_OF_EMPLOYEES) VALUES
    (0, 'Zaha Hadid Architects', '1980-01-01', 708),
    (1, 'Utzon Associates Architects', '1982-01-01', 69),
    (2, 'Grimm and Parker Architects', '1972-01-01', 70),
    (3, 'Diamond Schmitt Architects', '1975-01-01', 25);

INSERT INTO BUILDING_ARCHITECT(BUILDING_ID, ARCHITECT_ID) VALUES
    (0, 0),
    (0, 2),
    (1, 3),
    (1, 0),
    (2, 1),
    (2, 2),
    (3, 1),
    (3, 3)
