DROP TABLE IF EXISTS TYPES_OF_BUILDINGS CASCADE;
DROP TABLE IF EXISTS BUILDINGS CASCADE;
DROP TABLE IF EXISTS ARCHITECTS CASCADE;
DROP TABLE IF EXISTS BUILDING_ARCHITECT CASCADE;

CREATE TABLE TYPES_OF_BUILDINGS(
--                                    CODE VARCHAR(4) NOT NULL IDENTITY,
                                   CODE VARCHAR(4) NOT NULL,
                                   TYPE VARCHAR(25) NOT NULL ,
                                   REQUIRES_SPECIAL_PERMISSION BOOLEAN,

                                   PRIMARY KEY (TYPE)
);

CREATE TABLE BUILDINGS(
--                           ID INTEGER NOT NULL IDENTITY,
                          ID INTEGER NOT NULL,
                          NAME VARCHAR(30) NOT NULL UNIQUE,
                          LOCATION VARCHAR(30) NOT NULL,
                          HEIGHT INTEGER NOT NULL,
                          TYPE VARCHAR(25),

                          PRIMARY KEY (ID),
                          FOREIGN KEY (TYPE) REFERENCES TYPES_OF_BUILDINGS(TYPE)
                      );

CREATE TABLE ARCHITECTS(
--                            ID INTEGER NOT NULL IDENTITY,
                           ID INTEGER NOT NULL,
                           NAME VARCHAR(30) NOT NULL UNIQUE,
                           ESTABLISHMENT_DATE DATE,
                           NUMBER_OF_EMPLOYEES INTEGER NOT NULL,

                           PRIMARY KEY(ID)
                        );

CREATE TABLE BUILDING_ARCHITECT(
                                   BUILDING_ID INTEGER NOT NULL,
                                   ARCHITECT_ID INTEGER NOT NULL,

                                   FOREIGN KEY(BUILDING_ID) REFERENCES BUILDINGS(ID),
                                   FOREIGN KEY(ARCHITECT_ID) REFERENCES ARCHITECTS(ID)
);
